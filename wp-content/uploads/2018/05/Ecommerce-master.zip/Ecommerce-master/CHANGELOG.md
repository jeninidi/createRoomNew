## Initial version (15/03-2013)
Made initial commit of module