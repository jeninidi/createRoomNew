# Contributing to DIBS Shop Modules

To be written.